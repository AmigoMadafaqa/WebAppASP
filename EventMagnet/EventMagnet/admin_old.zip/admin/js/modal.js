// Get all modal
var modal = $(".modal");

// Get the button that opens the modal
var btn = $(".modal-btn");

// Get the <span> element that closes the modal
var span = $(".close");

var editBtn = $(".edit-btn");
var editSubmit = $(".edit-submit");
var cancelEditBtn = $(".edit-cancel");

editSubmit.hide();
cancelEditBtn.hide();


setTimeout(() => {
  const box = document.getElementsByClassName('popup-box');

  for(i = 0; i < box.length;i++) {
      box[i].style.display = "none";
  }

}, 1500);

jQuery.each(btn, function(i, item) {
    
    let index = $(item).attr("data-index");
    
    item.addEventListener("click", function(){
        $(".modal[data-index='" + index +"']").show();
    });
    
});

//// When the user clicks anywhere outside of the modal, close it
window.onclick = function(event) {
    
    
    for(let j = 0; j < modal.length; j++) {
        if (event.target == modal[j]) {
            modal.hide();
        }
    }
    

    
    jQuery.each(editBtn, function(i, item) {
        
        let index = $(item).attr("data-index");
        
        item.addEventListener("click", function(){
            $(item).hide();
            $("form[data-index='" + index +"'] .edit-field").attr("disabled", false);
            console.log($(".edit-cancel[data-index='" + index +"']"));  
            $(".edit-cancel[data-index='" + index +"']").css("display", "block");
            $(".edit-submit[data-index='" + index +"']").css("display", "block");
        });
        
    });
    
    jQuery.each(cancelEditBtn, function(i, item) {
        
        let index = $(item).attr("data-index");
        
        item.addEventListener("click", function(){
            $(".edit-btn[data-index='" + index +"']").show();
            $("form.edit-form[data-index='" + index +"'] .edit-field").attr("disabled", true);
            $(".edit-cancel[data-index='" + index +"']").hide();
            $(".edit-submit[data-index='" + index +"']").hide();
            
            let formInput = $("form.edit-form[data-index='" + index +"'] .edit-field");
            
            jQuery.each(formInput, function(i, item) {
                
                let originalVal = $(item).attr("data-value");
                
                $(item).val(originalVal);
                
            });
        });
        
    });
    
    // When the user clicks on <span> (x), close the modal
    jQuery.each(span, function(i, item) {
        
        let index = $(item).attr("data-index");
        
        item.addEventListener("click", function(){
            $(".modal[data-index='" + index +"']").hide();
        });
        
    });
    
}
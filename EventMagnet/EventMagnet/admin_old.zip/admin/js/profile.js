var editBtn = $("#profile-edit-btn");
var editSubmit = $("#edit-submit");
var cancelEditBtn = $("#edit-cancel");

editSubmit.hide();
cancelEditBtn.hide();

editBtn.on("click", function(){
    $(this).hide();
    editSubmit.show();
    cancelEditBtn.show();
    
    $(".profile-field").attr("disabled", false);
});

cancelEditBtn.on("click", function(){
    editSubmit.hide();
    cancelEditBtn.hide();
    editBtn.show();
    
    $(".profile-field").attr("disabled", true);

    jQuery.each($(".profile-field"), function(i, item) {
        
        let originalVal = $(item).attr("data-value");
        
        $(item).val(originalVal);
        
    });
    
});

setTimeout(() => {
  const box = document.getElementsByClassName('popup-box');

  for(i = 0; i < box.length;i++) {
      box[i].style.display = "none";
  }

}, 1500);


$("#change-password").on("click", function(){
    $("#modal-password").show();
});


$("#close-password").on("click", function(){
    $("#modal-password").hide();
});

